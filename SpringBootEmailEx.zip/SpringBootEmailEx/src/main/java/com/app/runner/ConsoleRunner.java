package com.app.runner;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import com.app.util.EmailUtil;

@Component
public class ConsoleRunner implements CommandLineRunner {
	@Autowired
	private EmailUtil util;
	
	@Override
	public void run(String... args) throws Exception {
		//adding attachment
		 FileSystemResource file = new FileSystemResource(new File("C:\\Users\\Administrator\\Desktop\\flower.jpg"));  
	 
		//sending mail
		boolean flag=util.send("rukalaraghuram@gmail.com", "From Spring boot", "Hello Raghuram Rukala", file);
		if(flag) System.out.println("Email Sent Successfully");
		else System.out.println("Failed To send An Email!! Please Check Problems ");
	}

}




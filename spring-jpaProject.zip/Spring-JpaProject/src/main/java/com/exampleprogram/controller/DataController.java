package com.exampleprogram.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.exampleprogram.dao.DataRepo;
import com.exampleprogram.model.Data;

@Controller //used to make the class as controller
public class DataController {
	@Autowired
	DataRepo repo;
	//url to access on browser
	@RequestMapping("/data")
	public String index()
	{
		return "index.jsp";
	}
	//adding data to table 
	@RequestMapping("/addData")
	public String addData(Data data)
	{
		repo.save(data);
		return "index.jsp";
	}
	//updating the existing data in table
	@PutMapping(path="/data")
	public Data updateData(@RequestBody Data data)
	{
		repo.save(data);
		return data;
	}
	
}




package com.exampleprogram.dao;

import org.springframework.data.repository.CrudRepository;

import com.exampleprogram.model.Data;

public interface DataRepo extends CrudRepository<Data,Integer> //Interface for generic CRUD operations on a repository for a specific type
	
{

	 
}
